<?php
error_reporting(E_ALL ^ E_DEPRECATED);
$connect = mysqli_connect("localhost","root","","dbname1");
mysqli_query($connect,"SET NAMES 'utf8'");
// error_reporting(E_ALL ^ E_DEPRECATED);
// $connect = mysqli_connect("118.69.225.61","arduinoTrung","ZfKar@SHkY#WsvBNa!","arduinotrung",8212);
// mysqli_query($connect,"SET NAMES 'utf8'");


?>
