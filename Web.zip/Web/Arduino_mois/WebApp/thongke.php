<style>
	p{text-align:center; }
	#thongke{text-align:center;}
</style>

<div id="thongke" >
<form action="" method="post" name="thongke" >
	<h3 style="color:red">THỐNG KÊ THỜI GIAN HOẠT ĐỘNG</h3>
  <p>
  	<label for="thietbi">Chọn Thiết Bị :</label>
   	  <select name="idthietbi" id="value1" >
      <option value="1">Máy Bơm 1</option>
      <option value="2">Máy Bơm 2</option>
    </select>
    <label for="ngay1">Ngày bắt đầu:</label>
    <input type="date" name="ngay1" id="ngay1" /></input>
    <label for="ngay2">Ngày kết thúc:</label>
    <input type="date" name="ngay2" id="ngay2"/></input>
     <input type="button" name="ketqua" id="ketqua" value="Lọc" /></input>
  
</form>
</div>
<div id="kq" style="height:313px; width: 70%; overflow:auto; margin:auto; ">

</div>



