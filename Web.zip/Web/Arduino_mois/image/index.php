<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>THIẾT LẶP ĐỘ ẨM</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" />
        <link href="css/bootstrap-theme.css" rel="stylesheet" />
    </head>
    
    <body>
     
    
     <hr/>
    <div class="container" style="text-align: center; margin: auto;">
        <b style="font-size: 100px; color: red;"> ERROR 404!</b><br/>
        <img src="ngontay.jpg"/>

    </div>
      <hr/>
    <script language="javascript" src="js/bootstrap.min.js"></script> 
   
    </body>
</html>