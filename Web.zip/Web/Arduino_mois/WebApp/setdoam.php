<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>THIẾT LẶP ĐỘ ẨM</title>
        <link href="css/bootstrap.min.css" rel="stylesheet" />
        <link href="css/bootstrap-theme.css" rel="stylesheet" />
    </head>
    
    <body>
     
    
     <hr/>
    <div class="container" style="text-align: center; margin: auto;">
         <div class="row">
          <div class="col-md-4 col-md-offset-4">
              <form class="form-signin" method="post" action="process.php">
                <h2 class="form-signin-heading text-center">THIẾT LẶP ĐỘ ẨM</h2>
                <label for="txtDA" class="sr-only">Nhập độ ẩm</label>
                <input type="text" id="txtDoAm" name="txtDoAm" class="form-control" placeholder="vui lòng nhập giá trị độ ẩm là số >0 và <100!" required autofocus style=" margin-top:15px">
                <button class="btn btn-lg btn-primary btn-block" type="submit" name="btnTC" style="margin-top:15px">Thiết Lặp</button>
              </form>
        
            </div>
        </div>
    </div>
      <hr/>
    <script language="javascript" src="js/bootstrap.min.js"></script> 
   
    </body>
</html>